<?php
session_abort()
?>