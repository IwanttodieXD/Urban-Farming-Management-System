<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qcu-cuai";

$conn = new mysqli($servername, $username, $password, $dbname);

// Retrieve data from potmixusage table
$stmt = $conn->prepare("SELECT * FROM potmixusage");
$stmt->execute();
$result = $stmt->get_result();
$data = array();
while ($row = $result->fetch_assoc()) {
    $data[] = $row;
}
$stmt->close();

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PotMix Records</title>
    <link rel="stylesheet" href="../css/attendance.css">
    <link rel="stylesheet" href="../css/header.css">
    <script src="../javascript/attendannce.js"></script>
</head>

<body>
    <header>
        <div class="info-container">
            <div class="text">Quezon City University - Center for Urban and Agriculture Innovation</div>
            <img src="../img/urban farming logo 3.png" alt="Logo" class="info-image">
        </div>
        
        <div class="content">
            <div class="location">
                Inventory Records / <span class="currentlocation">Inventory</span>
            </div>
        </div>
    </header>

    <div class="dateinput">
        <h1>PotMix Records</h1>
        <input class="startdate" type="date" name="startdate" id="startdate">
        <h3>To</h3>
        <input type="date" name="enddate" id="enddate">
        <button id="search-btn">Search</button>
    </div>

        <div class="tablediv">
            <h1>Inventory Records</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Employee ID</th>
                        <th>Item Name</th>
                        <th>Quantity Taken</th>
                        <th>Date</th>
                    </tr>
                </thead>
                
            <tbody id="plantTableBody">
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "qcu-cuai";

            $conn = new mysqli($servername, $username, $password, $database);

            if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            }
            $sql = 
            "SELECT * 
            FROM potmixusage
            ORDER BY UsageID DESC";
            
            if (isset($_GET['startdate']) && isset($_GET['enddate'])) {
                $startdate = $_GET['startdate'];
                $enddate = $_GET['enddate'];

                if ($startdate !== '' && $enddate !== '') {
                    $sql = 
                    "SELECT * 
                    FROM potmixusage
                    WHERE UsageDate BETWEEN '$startdate' AND '$enddate'
                    ORDER BY UsageID DESC";
                } else {
                    $sql = 
                    "SELECT * 
                    FROM potmixusage
                    ORDER BY UsageID DESC";
                }
            } else {
                $sql = 
                "SELECT * 
                FROM potmixusage
                ORDER BY UsageID DESC";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['EmployeeID']) . "</td>";
        	        echo "<td>" . htmlspecialchars($row['ItemName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Quantity']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['UsageDate']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='9'>No records found</td></tr>";
            }

            $conn->close();
            ?>
            </tbody>
            </table>
        </div>
    <script>
        document.getElementById('search-btn').addEventListener('click', function() {
            var startdate = document.getElementById('startdate').value;
            var enddate = document.getElementById('enddate').value;
            if (startdate === '' && enddate === '') {
                window.location.href = 'Records_PotMix.php';
            } else {
                window.location.href = '?startdate=' + startdate + '&enddate=' + enddate;
            }
        });
    </script>
</body>
</html>