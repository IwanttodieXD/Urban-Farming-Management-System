<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Summary</title>
    <link rel="stylesheet" href="../css/attendance.css">
    <link rel="stylesheet" href="../css/header.css">
    <script src="../javascript/attendannce.js"></script>
</head>
<body>
    <header>
        <div class="info-container">
            <div class="text">Quezon City University - Center for Urban and Agriculture Innovation</div>
            <img src="../img/urban farming logo 3.png" alt="Logo" class="info-image">
        </div>
        
        <div class="content">
            <div class="location">
                Attendance Summmary / <span class="currentlocation">Inventory</span>
            </div>
        </div>
    </header>

    <div class="dateinput">
        <h1>Attendance Summary</h1>
        <input class="startdate" type="date" name="startdate" id="startdate">
        <h3>To</h3>
        <input type="date" name="enddate" id="enddate">
        <button id="search-btn">Search</button>
    </div>

    <div class="tablediv">
        <table border="1">
            <thead>
                <tr>
                    <th>Employee Id</th>
                    <th>Name</th>
                    <th>Designation</th>
                    <th>Position</th>
                    <th>Date</th>
                    <th>Time In</th>
                    <th>Time Out</th>
                </tr>
            </thead>
            <tbody id="plantTableBody">
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "qcu-cuai";

            $conn = new mysqli($servername, $username, $password, $database);

            if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            }

            if (isset($_GET['startdate']) && isset($_GET['enddate'])) {
                $startdate = $_GET['startdate'];
                $enddate = $_GET['enddate'];

                if ($startdate !== '' && $enddate !== '') {
                    $sql = 
                    "SELECT a.AttendanceID, a.EmployeeID, e.EmployeeID, CONCAT(e.Lname, ', ', e.Fname, ' ', e.Mname) AS Name, e.UserType, e.Position, a.AttendanceDate, a.TimeIn, a.TimeOut
                    FROM attendance as a
                    INNER JOIN employee_tb as e
                    ON a.EmployeeID = e.EmployeeID
                    WHERE a.AttendanceDate BETWEEN '$startdate' AND '$enddate'
                    ORDER BY a.AttendanceID DESC";
                } else {
                    $sql = "SELECT a.AttendanceID, a.EmployeeID, e.EmployeeID, CONCAT(e.Lname, ', ', e.Fname, ' ', e.Mname) AS Name, e.UserType, e.Position, a.AttendanceDate, a.TimeIn, a.TimeOut
                    FROM attendance as a
                    INNER JOIN employee_tb as e
                    ON a.EmployeeID = e.EmployeeID
                    ORDER BY a.AttendanceID DESC";
                }
            } else {
                $sql = "SELECT a.AttendanceID, a.EmployeeID, e.EmployeeID, CONCAT(e.Lname, ', ', e.Fname, ' ', e.Mname) AS Name, e.UserType, e.Position, a.AttendanceDate, a.TimeIn, a.TimeOut
                    FROM attendance as a
                    INNER JOIN employee_tb as e
                    ON a.EmployeeID = e.EmployeeID
                    ORDER BY a.AttendanceID DESC";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['EmployeeID']) . "</td>";
        	        echo "<td>" . htmlspecialchars($row['Name']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['UserType']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Position']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['AttendanceDate']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['TimeIn']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['TimeOut']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='9'>No records found</td></tr>";
            }

            $conn->close();
            ?>
            </tbody>
        </table>
        </div>
        <script>
        document.getElementById('search-btn').addEventListener('click', function() {
            var startdate = document.getElementById('startdate').value;
            var enddate = document.getElementById('enddate').value;
            if (startdate === '' && enddate === '') {
                window.location.href = 'AttendanceSummary.php';
            } else {
                window.location.href = '?startdate=' + startdate + '&enddate=' + enddate;
            }
        });
    </script>
</body>
</html>