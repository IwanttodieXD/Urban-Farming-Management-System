<?php
// Database configuration
$servername = "localhost";
$username = "root"; // Default XAMPP username
$password = ""; // Default XAMPP password (usually empty)
$dbname = "qcu-cuai"; // Your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if form is submitted for adding a new employee
if ($_SERVER["REQUEST_METHOD"] == "POST" && !isset($_POST['edit'])) {
    $firstname = $_POST['fname'];
    $middlename = $_POST['mname'];
    $lastname = $_POST['lname'];
    $birthdate = $_POST['bdate'];
    $sex = $_POST['sex'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $hiredate = $_POST['hiredate'];
    $position = $_POST['position'];
    $employeeid = $_POST['employeeid'];
    $usertype = $_POST['role'];
    $password = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO employee_tb (Fname, Mname, Lname, Bdate, Sex, Contact, Email, Address, HireDate, Position, EmployeeID, UserType, Password) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->bind_param("sssssssssssss", $firstname, $middlename, $lastname, $birthdate, $sex, $contact, $email, $address, $hiredate, $position, $employeeid, $usertype, $password);

    // Execute the statement
    if ($stmt->execute()) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Check if form is submitted for editing an employee
if (isset($_POST['edit'])) {
    $employeeid = $_POST['employeeid'];
    $firstname = $_POST['fname'];
    $middlename = $_POST['mname'];
    $lastname = $_POST['lname'];
    $birthdate = $_POST['bdate'];
    $sex = $_POST['sex'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $hiredate = $_POST['hiredate'];
    $position = $_POST['position'];
    $usertype = $_POST['role'];
    $password = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("UPDATE employee_tb SET Fname=?, Mname=?, Lname=?, Bdate=?, Sex=?, Contact=?, Email=?, Address=?, HireDate=?, Position=?, UserType=?, Password=? WHERE EmployeeID=?");
    $stmt->bind_param("sssssssssssss", $firstname, $middlename, $lastname, $birthdate, $sex, $contact, $email, $address, $hiredate, $position, $usertype, $password, $employeeid);

    // Execute the statement
    if ($stmt->execute()) {
        echo "Record updated successfully";
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close statement
    $stmt->close();
}

// Fetch employee list
$employeeList = [];
$result = $conn->query("SELECT * FROM employee_tb");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $employeeList[] = $row;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personnel List</title>
    <link rel="stylesheet" href="../css/attendance.css">
    <link rel="stylesheet" href="../css/header.css">
</head>
<body>
    <header>
        <div class="info-container">
            <div class="text">Quezon City University - Center for Urban and Agriculture Innovation</div>
            <img src="../img/urban farming logo 3.png" alt="Logo" class="info-image">
        </div>
        
 <div class="content">
            <div class="location">
                Personnel List / <span class="currentlocation">Plants</span>
            </div>
        </div>
    </header>

    <h2>Employee List</h2>
    <div class="tablediv">
        <table border="1">
            <thead>
                <tr>
                    <th>Image</th>
                    <th>Employee Id</th>
                    <th>Name</th>
                    <th>Position</th>
                    <th>Contact</th>
                          <th>Action</th>
                </tr>
            </thead>
            <tbody id="EmployeeList">
                <?php foreach ($employeeList as $employee): ?>
                <tr>
                    <td><img src="/urbfrm/php/<?php echo $employee['Image']; ?>" width="50" height="50"></td>
                    <td><?php echo htmlspecialchars($employee['EmployeeID']); ?></td>
                    <td><?php echo htmlspecialchars($employee['Fname'] . ' ' . $employee['Mname'] . ' ' . $employee['Lname']); ?></td>
                    <td><?php echo htmlspecialchars($employee['Position']); ?></td>
                    <td><?php echo htmlspecialchars($employee['Contact']); ?></td>
                    <td>
                        <a href="/urbfrm/php/editemployee.php?id=<?php echo htmlspecialchars($employee['EmployeeID']); ?>">Edit</a>
                        <a href="/urbfrm/php/deleteemployee.php?EmployeeID=<?php echo htmlspecialchars($employee['EmployeeID']); ?>" class="button button-delete" onclick="return confirm('Are you sure you want to delete this item?');">Delete</a>
                </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>