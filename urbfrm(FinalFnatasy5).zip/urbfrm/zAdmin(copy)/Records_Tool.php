<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tools Records</title>
    <link rel="stylesheet" href="../css/attendance.css">
    <link rel="stylesheet" href="../css/header.css">
    <script src="../javascript/attendannce.js"></script>
</head>
<body>
    <header>
        <div class="info-container">
            <div class="text">Quezon City University - Center for Urban and Agriculture Innovation</div>
            <img src="../img/urban farming logo 3.png" alt="Logo" class="info-image">
        </div>
        
        <div class="content">
            <div class="location">
                Tools Borrowed Records / <span class="currentlocation">Inventory</span>
            </div>
        </div>
    </header>
    <div class="dateinput">
        <h1>Tools Record</h1>
        <input class="startdate" type="date" name="startdate" id="startdate">
        <h3>To</h3>
        <input type="date" name="enddate" id="enddate">
        <button id="search-btn">Search</button>
    </div>
    <!--Tools Borrowed-->
        <div class="tablediv">
            <h1>Records of Tools Borrowed</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Borrower's ID</th>
                        <th>Item Name</th>
                        <th>Quantity Borrowed</th>
                        <th>Borrower's Name</th>
                        <th>Borrower's Contact</th>
                        <th>Affiliation</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody id="plantTableBody">
                <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "qcu-cuai";

            $conn = new mysqli($servername, $username, $password, $database);

            if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            }
            
            if (isset($_GET['startdate']) && isset($_GET['enddate'])) {
                $startdate = $_GET['startdate'];
                $enddate = $_GET['enddate'];

                if ($startdate !== '' && $enddate !== '') {
                    $sql = 
                    "SELECT CONCAT(EmployeeID, Student_Id) AS 'Borrower ID',
                    toolsusage.* 
                    FROM toolsusage
                    WHERE bStatus = 'Borrowed' AND UsageDate BETWEEN '$startdate' AND '$enddate'
                    ORDER BY UsageID DESC";
                } else {
                    $sql = 
                    "SELECT CONCAT(EmployeeID, Student_Id) AS 'Borrower ID',
                    toolsusage.* 
                    FROM toolsusage
                    WHERE bStatus = 'Borrowed'
                    ORDER BY UsageID DESC";
                }
            } else {
                $sql = 
                "SELECT CONCAT(EmployeeID, Student_Id) AS 'Borrower ID',
                toolsusage.*  
                FROM toolsusage
                WHERE bStatus = 'Borrowed'
                ORDER BY UsageID DESC";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['Borrower ID']) . "</td>";
        	        echo "<td>" . htmlspecialchars($row['ToolName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Quantity']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Bname']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Bcontact']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Baffil']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['UsageDate']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Bstatus']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='9'>No records found</td></tr>";
            }

            $conn->close();
            ?>
            </tbody>
            </table>
            <br>
            <!--tools returned-->
            </div>
            <div class="tablediv">
            <h1>Records of Tools Returned</h1>
            <table border="1">
                <thead>
                    <tr>
                        <th>Borrower's ID</th>
                        <th>Item Name</th>
                        <th>Quantity Borrowed</th>
                        <th>Borrower's Name</th>
                        <th>Borrower's Contact</th>
                        <th>Affiliation</th>
                        <th>Date</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody id="plantTableBody">
                <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "qcu-cuai";

            $conn = new mysqli($servername, $username, $password, $database);

            if ($conn->connect_error) {
            die("Connection failed: " . $conn->connect_error);
            }
            
            if (isset($_GET['startdate']) && isset($_GET['enddate'])) {
                $startdate = $_GET['startdate'];
                $enddate = $_GET['enddate'];

                if ($startdate !== '' && $enddate !== '') {
                    $sql = 
                    "SELECT CONCAT(EmployeeID, Student_Id) AS 'Borrower ID',
                    toolsusage.* 
                    FROM toolsusage
                    WHERE bStatus = 'Returned' AND UsageDate BETWEEN '$startdate' AND '$enddate'
                    ORDER BY UsageID DESC";
                } else {
                    $sql = 
                    "SELECT CONCAT(EmployeeID, Student_Id) AS 'Borrower ID',
                    toolsusage.* 
                    FROM toolsusage
                    WHERE bStatus = 'Returned'
                    ORDER BY UsageID DESC";
                }
            } else {
                $sql = 
                "SELECT CONCAT(EmployeeID, Student_Id) AS 'Borrower ID',
                toolsusage.*  
                FROM toolsusage
                WHERE bStatus = 'Returned'
                ORDER BY UsageID DESC";
            }

            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row['Borrower ID']) . "</td>";
        	        echo "<td>" . htmlspecialchars($row['ToolName']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Quantity']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Bname']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Bcontact']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Baffil']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['UsageDate']) . "</td>";
                    echo "<td>" . htmlspecialchars($row['Bstatus']) . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='9'>No records found</td></tr>";
            }

            $conn->close();
            ?>
                </tbody>
            </table>
            </div>
            <script>
        document.getElementById('search-btn').addEventListener('click', function() {
            var startdate = document.getElementById('startdate').value;
            var enddate = document.getElementById('enddate').value;
            if (startdate === '' && enddate === '') {
                window.location.href = 'Records_Tool.php';
            } else {
                window.location.href = '?startdate=' + startdate + '&enddate=' + enddate;
            }
        });
    </script>
</body>
</html>