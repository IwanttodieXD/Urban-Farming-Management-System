<?php
session_start(); // Start the session at the beginning of the file
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Potting Mix Inventory</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="../css/tool.css">
    <link rel="stylesheet" href="../css/header.css">
    <script src="../javascript/showforms.js"></script>
</head>
<body>
    <header>
        <div class="info-container">
            <div class="text">Quezon City University - Center for Urban and Agriculture Innovation</div>
            <img src="../img/urban farming logo 3.png" alt="Logo" class="info-image">
        </div>
        
        <div class="content">
            <div class="location">
                Potting Mix / <span class="currentlocation">Inventory</span>
            </div>
        </div>
    </header>
    
    <div class="table-container">
        <a href="#" class="button button-add" onclick="showInsertForm(event)">Insert</a>
        <br><br>
    
        <table>
            <tr>
                <th>Pot Mix</th>
                <th>Stock</th>
                <th>Status</th>
                <th>Actions</th>
            </tr>
            <?php
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "qcu-cuai";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $sql = "SELECT * FROM potmix";
            $result = $conn->query($sql);

            if (!$result) {
                die("Invalid query: " . $conn->error);
            }
            while($row = $result->fetch_assoc()){
                // Determine the status based on the stock level
                if ($row['Stock'] > 5) {
                    $status = "In Stock";
                } elseif ($row['Stock'] > 0) {
                    $status = "Low Stock";
                } else {
                    $status = "Out of Stock";
                }

                echo "
                    <tr>
                        <td>{$row['ItemName']}</td>
                        <td>{$row['Stock']}</td>
                        <td>{$status}</td>
                        <td>
                            <a href='#' class='button button-edit' onclick=\"showEditForm({$row['MixID']}, '{$row['ItemName']}', {$row['Stock']})\">Edit</a>
                            <a href='/urbfrm/php/deletepotmix.php?MixID={$row['MixID']}' class='button button-delete' onclick=\"return confirm('Are you sure you want to delete this item?');\">Delete</a>
                        </td>
                    </tr>
                ";
            }
            ?>
        </table>
    </div>

    <div class="overlay" id="overlay"></div>

    <div class="container" id="insertForm">
        <h2>Insert Pot Mix</h2>
        <div class="message">
            <?php
            if (isset($_SESSION[' message'])) {
                echo $_SESSION['message'];
                unset($_SESSION['message']);
            }
            ?>
        </div>
        <form method="post" action="\urbfrm\php\insertpotmix.php">
            <div class="form-group">
                <label for="item">Item</label>
                <input type="text" id="item" name="item" required value="">
            </div>
            <div class="form-group">
                <label for="stock">Stock</label>
                <input type="number" id="stock" name="stock" min="0" max="100" required value="">
            </div>
            <div class="form-group">
                <button class="button button-done" type="submit">Done</button>
                <button class="button button-cancel" type="button" onclick="hideInsertForm()">Cancel</button>
            </div>
        </form>
    </div>

    <div class="container" id="editForm" style="display:none;">
        <h2>Edit Pot Mix</h2>
        <div class="message" id="editMessage"></div>
        <form method="post" action="\urbfrm\php\updatepotmix.php" id="updateForm">
            <input type="hidden" id="editMixID" name="MixID" value="">
            <div class="form-group">
                <label for="editItem">Item</label>
                <input type="text" id="editItem" name="item" required value="">
            </div>
            <div class="form-group">
                <label for="editStock">Stock</label>
                <input type="number" id="editStock" name="stock" min="0" max="100" required value="">
            </div>
            <div class="form-group">
                <button class="button button-done" type="submit">Update</button>
                <button class="button button-cancel" type="button" onclick="hideEditForm()">Cancel</button>
            </div>
        </form>
    </div>

    <script>
        function showInsertForm(event) {
            event.preventDefault();
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('insertForm').style.display = 'block';
        }

        function hideInsertForm() {
            document.getElementById('overlay').style.display = 'none';
            document.getElementById('insertForm').style.display = 'none';
        }

        function showEditForm(mixID, itemName, stock) {
            document.getElementById('editMixID').value = mixID;
            document.getElementById('editItem').value = itemName;
            document.getElementById('editStock').value = stock;
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('editForm').style.display = 'block';
        }

        function hideEditForm() {
            document.getElementById('overlay').style.display = 'none';
            document.getElementById('editForm').style.display = 'none';
        }
    </script>
</body>
</html>